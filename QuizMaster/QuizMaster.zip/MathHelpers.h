#pragma once

class MathHelpers
{
public:
	static size_t getClosestPowerOf(size_t num, size_t of);
};