#pragma once

enum class Role {
	Admin,
	Player
};