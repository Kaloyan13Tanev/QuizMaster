#pragma once

enum class QuestionType
{
	TrueOrFalse,
	SingleChoice,
	MultipleChoice,
	ShortAnswer,
	MatchingPairs
};
